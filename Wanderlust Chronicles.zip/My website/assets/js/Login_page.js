/* Animations */
var $wrap = $('#main');
var $signUpBtn = $wrap.find('#signUpBtn');
var $loginBtn = $wrap.find("#loginBtn");

$signUpBtn.on('click', function() {
    $wrap.addClass('singUpActive');
    $wrap.removeClass('loginActive');
});

$loginBtn.on('click', function() {
    $wrap.addClass('loginActive');
    $wrap.removeClass('singUpActive');
});

/* Validation */
function validation() {
	var username = document.getElementById("input_text").value;
	var password = document.getElementById("input_password").value;
	var error_msg = document.getElementById("error");
	var success_msg = document.getElementById("success");

	if (input_text.value.length <= 4 || input_password.value.length <= 4 || 
		(username !== "admin" && password !== "123123" ) ) {
		error_msg.style.display = "inline-block";
	}
	else {
		success_msg.style.display = "inline-block";
		error_msg.style.display = "none";
		window.location.href = "index.html";
	}	
}